<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <title>Foodies website</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    
</head>
<body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

<nav>
<?php
include("navbar.php");

?>
</nav>
<main>
<div class="container1">
    <div class="subcontainer">
        <div class="text1">
            <h1>Welcome to Foodie</h1><br>
        </div>
        <div class="text2">
            <p>Where we provide the best baking flavours<br>
            For you where ever you are found<br></p>
        </div>
        <button><a href="">LEARN MORE</a></button>

    </div>
</div>
<div class="textcontainer">
    <h1>Whats new<br></h1>
    <h3>more to taste</h3>
    <p>Discover and order best bakings<br>
    For your events and more</p>
</div>

<div class="container2">
    <div class="card">
        <img src="images/bak1.jpg" alt="">
        <div class="text3">
            <p>pain complet<br>
             125FCFA each</p>
        </div>
    </div>

    <div class="card">
        <img src="images/bak2.jpg" alt="">
        <div class="text3">
            <p>baked bread<br>
             500FCFA each</p>
        </div>
    </div>

    <div class="card">
        <img src="images/bak3.jpg" alt="">
        <div class="text3">
        <p>birthday cake<br>
             10000FCFA unit</p>
        </div>
    </div>

    <div class="card">
        <img src="images/bak10.jpg" alt="">
        <div class="text3">
        <p>chocolate cake<br>
             2000FCFA each</p>
        </div>
    </div>

    <div class="card">
        <img src="images/bak5.jpg" alt="">
        <div class="text3">
        <p>cookies with chocolate pepite<br>
             500FCFA each</p>
        </div>  
    </div>

    <div class="card">
        <img src="images/bak7.jpg" alt="">
        <div class="text3">
        <p>Donuts<br>
             500FCFA each</p>
        </div>   
    </div>
    <div class="card">
        <img src="images/bak8.jpg" alt="">
        <div class="text3">
        <p>Bread chocolate cake<br>
             3000FCFA each</p>
        </div>
    </div>
    <div class="card">
        <img src="images/bak9.jpg" alt="">
        <div class="text3">
        <p>chocolate biscuit<br>
             1000FCFA each</p>
        </div>
    </div>   
    
</div>

<div class="container3">
    <div class="firstcontainer">
        <div class="firstrow">
            <img src="images/bak9.jpg" alt=""><br>
        </div>
        <div class="secondrow">
            <img src="images/bak8.jpg" alt=""><br>
        </div>
        <div class="thirdrow">
            <img src="images/bak4.jpg" alt=""><br>
        </div>
        <div class="fourthrow">
            <img src="images/bak1.jpg" alt=""><br>
        </div>
        <div class="fifthrow">
            <img src="images/bak7.jpg" alt=""><br>
        </div>
    </div>
        <div class="secondcontainer">
            <div class="text4">
                <h1>Our Delice</h1>
            </div>

            <div id="foodies" class="carousel slide">
                <div class="carousel-indicators">
                  <button type="button" data-bs-target="#foodies" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                  <button type="button" data-bs-target="#foodies" data-bs-slide-to="1" aria-label="Slide 2"></button>
                  <button type="button" data-bs-target="#foodies" data-bs-slide-to="2" aria-label="Slide 3"></button>
                </div>
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img src="images/bak2.jpg" class="d-block w-100" alt="bak">
                    <div class="carousel-caption d-none d-md-block">
                      <h5>Bread</h5>
                      <p></p>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <img src="images/bak3.jpg" class="d-block w-100" alt="bak">
                    <div class="carousel-caption d-none d-md-block">
                      <h5>Birthday Cake</h5>
                      <p></p>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <img src="images/bak4.jpg" class="d-block w-100" alt="bak">
                    <div class="carousel-caption d-none d-md-block">
                      <h5>Fruity baking</h5>
                      <p></p>
                    </div>
                  </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Next</span>
                </button>
              </div>
            
        </div>
    </div>

</div>
</main>





<footer>
<?php
include("footer.php");
?>

</footer>
</body>

</html>